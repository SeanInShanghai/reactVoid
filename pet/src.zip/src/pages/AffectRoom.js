/**
 * Created by fsg on 2018/3/19.
 */
import React from 'react';
import {Component} from 'react';
//影响室
class AffectRoom extends Component {
    render(){
        return(
            <div> I am front AffectRoom</div>
        );
    }
}

export default AffectRoom;