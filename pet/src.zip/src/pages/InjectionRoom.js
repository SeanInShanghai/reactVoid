/**
 * Created by fsg on 2018/3/19.
 */
import React from 'react';
import {Component} from 'react';
//注射室
class InjectionRoom extends Component {
    render(){
        return(
            <div> I am front desk</div>
        );
    }
}

export default InjectionRoom;