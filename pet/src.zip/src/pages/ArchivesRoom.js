/**
 * Created by fsg on 2018/3/19.
 */
import React from 'react';
import {Component} from 'react';

class ArchivesRoom extends Component {
    render(){
        return(
            <div>
                {
                    <div>
                        This is the archives room .
                    </div>
                }
            </div>
        );
    }
}

export default ArchivesRoom;