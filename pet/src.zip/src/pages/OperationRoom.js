/**
 * Created by fsg on 2018/3/19.
 */
import React from 'react';
import {Component} from 'react';
//手术室
class OperationRoom extends Component {
    render(){
        return(
            <div> I am front desk</div>
        );
    }
}

export default OperationRoom;