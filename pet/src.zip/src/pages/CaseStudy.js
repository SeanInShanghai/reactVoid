/**
 * Created by fsg on 2018/3/21.
 */

import React from 'react';
import {Component} from 'react';
import {Layout, Menu, Icon} from 'antd';
import { Row, Col } from 'antd';
import {Switch, Route, Link} from 'react-router-dom';
import { Tag } from 'antd';
import './Test.css';
import MyHeader from '../CurHeader';
import './CaseStudy.css';
const {Header, Content, Footer, Sider} = Layout;


const illness = {'data': [
    {'key':1, 'name':'传染病', 'cases':['传染病1', '传染病2', '传染病3']},
    {'key':2, 'name':'寄生虫病', 'cases':['传染病1', '传染病2', '传染病3']},
    {'key':3, 'name':'内科病例', 'cases':['传染病1', '传染病2', '传染病3']},
    {'key':4, 'name':'外产科病例', 'cases':['传染病1', '传染病2', '传染病3']},
    {'key':5, 'name':'常用手术', 'cases':['传染病1', '传染病2', '传染病3']},
    {'key':6, 'name':'免疫', 'cases':['传染病1', '传染病2', '传染病3']}]};

//病例学习
class CaseStudy extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: illness
        };
    }
    render(){

        // var menus = [];
        // for(var i=0; this.state.data.length; i++){
        //     console.debug("sdsd");
        //     menus.push(<Menu.Item key={this.state.data.data[i].key} className="Menu-item">
        //         <Link to="/frontdesk" class="Menu-link">
        //             <span className="nav-text" value={this.state.data.data[1].key}>{this.state.data.data[i].name}</span>
        //         </Link>
        //     </Menu.Item>);
        // }
        // menus.push(<div>I am fine</div>);
        // menus.push(<Menu.Item className="Menu-item"><span className="nav-text">sdsds</span></Menu.Item>);
        let menus = this.state.data;
        return(
            <Layout>
                <MyHeader/>
                <Layout>
                    <Sider
                        breakpoint="md"
                        collapsedWidth="0"
                        onCollapse={(collapsed, type) => {
                            console.log(collapsed, type);
                        }}
                        style={{textAlign:'center', height:'100%', backgroundColor:'#fff'}}>

                        <div className="logo" />
                        <Menu theme="light" mode="inline" defaultSelectedKeys={['1']} >

                            {/*<Menu.Item key="1" className="Menu-item">
                                <Link to="/frontdesk" class="Menu-link">
                                    <span className="nav-text" value={this.state.data.data[1].key}>{this.state.data.data[0].name}</span>
                                </Link>
                            </Menu.Item>
                            <Menu.Item key="2" className="Menu-item">
                                <Link to="/archivesroom" class="Menu-link">
                                    <span className="nav-text">寄生虫病</span>
                                </Link>
                            </Menu.Item>
                            <Menu.Item key="3" className="Menu-item">
                                <Link to="/archivesroom" class="Menu-link">
                                    <span className="nav-text">内科病例</span>
                                </Link>
                            </Menu.Item>
                            <Menu.Item key="4" className="Menu-item">
                                <Link to="/archivesroom" class="Menu-link">
                                    <span className="nav-text">外产科病例</span>
                                </Link>
                            </Menu.Item>
                            <Menu.Item key="5" className="Menu-item">
                                <Link to="/archivesroom" class="Menu-link">
                                    <span className="nav-text">常用手术</span>
                                </Link>
                            </Menu.Item>
                            <Menu.Item key="6" className="Menu-item">
                                <Link to="/archivesroom" class="Menu-link">
                                    <span className="nav-text">免疫</span>
                                </Link>
                            </Menu.Item>*/}
                            {
                                /*menus.map(function (menu){
                                    return <Menu.Item key="6" className="Menu-item">
                                        <Link to="/archivesroom" class="Menu-link">
                                            <span className="nav-text">免疫</span>
                                        </Link>
                                    </Menu.Item>
                                })*/
                                Object.keys(menus).map(function (menu) {
                                    return <Menu.Item key="6" className="Menu-item">
                                        <Link to="/archivesroom" class="Menu-link">
                                            <span className="nav-text">免疫</span>
                                        </Link>
                                    </Menu.Item>
                                })
                            }

                        </Menu>
                    </Sider>
                    <Layout>
                        <div style={{marginTop:'10px'}}>
                            <Row style={{textAlign:'center'}}>
                                <Col style={{backgroundColor:'#00a0e9b3'}} xs={{ span: 5, offset: 1 }} lg={{ span: 6, offset: 2 }}>Col</Col>
                                <Col style={{backgroundColor:'#00a0e9b3'}} xs={{ span: 11, offset: 1 }} lg={{ span: 6, offset: 2 }}>Col</Col>
                                <Col style={{backgroundColor:'#00a0e9b3'}} xs={{ span: 5, offset: 1 }} lg={{ span: 6, offset: 2 }}>Col</Col>
                            </Row>
                        </div>

                    </Layout>
                </Layout>
            </Layout>
        );
    }
}

export default CaseStudy;