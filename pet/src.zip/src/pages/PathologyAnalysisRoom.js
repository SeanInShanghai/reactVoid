/**
 * Created by fsg on 2018/3/19.
 */
import React from 'react';
import {Component} from 'react';
//病理分析室
class PathologyAnalysisRoom extends Component {
    render(){
        return(
            <div> I am front desk</div>
        );
    }
}

export default PathologyAnalysisRoom;