/**
 * Created by fsg on 2018/3/19.
 */
import React from 'react';
import {Component} from 'react';
//手术准备室
class OperationPrepareRoom extends Component {
    render(){
        return(
            <div> I am front desk</div>
        );
    }
}

export default OperationPrepareRoom;