/**
 * Created by fsg on 2018/3/19.
 */
import React from 'react';
import {Component} from 'react';
//专科检查室
class SpecialConsultingRoom extends Component {
    render(){
        return(
            <div> I am front desk</div>
        );
    }
}

export default SpecialConsultingRoom;