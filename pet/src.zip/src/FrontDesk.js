/**
 * Created by fsg on 2018/3/18.
 */
import React from 'react';
import {Component} from 'react';

class FrontDesk extends Component {
    render(){
        return(
            <div> I am front desk</div>
        );
    }
}

export default FrontDesk;