/**
 * Created by fsg on 2018/4/14.
 */
import React from 'react';
import {Component} from 'react';
import {Carousel} from 'antd';
import './frontdesk.css';
require('./css/style.css');
require('./css/slider.css');

//前台



class SpecificCase extends Component {
    render() {
        return (

            <div>test
            </div>
        )
    }
}

export default SpecificCase;