/**
 * Created by fsg on 2018/3/19.
 */
import React from 'react';
import {Component} from 'react';
//免疫室
class ImmunityRoom extends Component {
    render(){
        return(
            <div> I am front desk</div>
        );
    }
}

export default ImmunityRoom;