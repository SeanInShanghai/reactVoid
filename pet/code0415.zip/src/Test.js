/**
 * Created by fsg on 2018/3/20.
 */

import React from 'react';
import {Component} from 'react';
import './Test.css';

//前台



class Test extends Component {
    render(){
        return(
            <div>
                Test
            </div>

        );
    }
}

export default Test;